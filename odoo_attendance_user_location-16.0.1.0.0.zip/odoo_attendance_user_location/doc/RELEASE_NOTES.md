## Module <odoo_attendance_user_location>

#### 12.07.2023
#### Version 16.0.1.0.0
#### ADD

- Initial commit for Geolocation in HR Attendance